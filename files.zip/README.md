# 📅 Daily Planner Pro - Panduan Lengkap

Organizer kehidupan lengkap dengan fitur cycle tracker, jadwal sholat, analytics, dan banyak lagi!

## ✨ Fitur Lengkap

### 📋 Task Management
- ✅ Tambah task custom dengan waktu, durasi, kategori
- 🎨 7 Kategori warna: Kerja, Pribadi, Olahraga, Belajar, Ibadah, Keluarga, Hobi
- ⚡ 4 Level prioritas: Urgent, High, Normal, Low
- 🔁 Recurring tasks (harian, weekdays, weekend, weekly)
- 🔔 Smart reminders (tepat waktu / 5/15/30/60 menit sebelumnya)
- 📝 Catatan untuk setiap task
- ✅ Checklist interaktif
- 🗑️ Hapus task

### 📅 Multiple Views
- **Hari Ini** - Focus mode untuk task hari ini
- **Calendar** - View bulanan dengan visual task
- **Week Planner** - Planning 7 hari sekaligus
- **Timeline** - Schedule per jam (coming soon)

### 🕌 Jadwal Sholat & Tracker
- ⏰ Jadwal sholat otomatis (5 waktu)
- 🔔 Notifikasi adzan
- ✅ Checklist sholat harian
- 📊 Tracking sholat tepat waktu
- 📍 Support 5 kota besar Indonesia

### 🩸 Cycle Tracker
- 📆 Prediksi siklus menstruasi
- 📊 4 Fase tracking: Menstruasi, Folikuler, Ovulasi, Luteal
- 💡 Activity suggestions per fase
- 🎯 Customizable cycle length & period length

### ✅ Habit Tracker
- 🔥 Streak counter
- 📊 Progress 7 hari
- 🎯 Custom target
- ✨ Multiple habits

### 📝 Templates
- 🌅 Morning Routine
- 💼 Work Day
- 🩸 Period Days (rest mode)
- 🎉 Weekend
- 📚 Study Day
- 💪 Workout Day

### 📊 Analytics & Insights
- 📈 Produktivitas 7 hari
- 📉 Trend naik/turun
- 🎯 Completion rate per kategori
- 🔥 Streak hari produktif
- 🕌 Prayer completion rate
- 📊 Visual charts

### 💾 Data Management
- ☁️ Auto-save setiap 30 detik
- 📥 Export backup (JSON)
- 📤 Import backup
- 🔄 Reset data
- 💽 LocalStorage (offline support)

### 📱 Progressive Web App (PWA)
- 📲 Install di HP seperti app
- 📶 Offline mode
- 🔔 Push notifications
- 🚀 Fast loading
- 💾 Auto-update

---

## 🚀 Cara Install & Pakai

### 1️⃣ Buka Aplikasi

**Di Laptop/PC:**
1. Extract semua file ke satu folder
2. Buka `setup_planner.html` di browser (Chrome/Firefox/Edge)
3. Klik "Mulai Gunakan Sekarang"

**Di HP:**
1. Upload semua file ke hosting (gratis: GitHub Pages, Netlify, Vercel)
2. Atau buka file lokal di browser HP
3. Buka `setup_planner.html`

### 2️⃣ Install sebagai App (PWA)

**Android (Chrome):**
1. Buka web planner di Chrome
2. Klik menu (⋮) di pojok kanan atas
3. Pilih "Add to Home Screen" atau "Install app"
4. Klik "Add" / "Install"
5. Icon app muncul di home screen!

**iPhone (Safari):**
1. Buka web planner di Safari
2. Klik tombol Share (□↑) di bawah
3. Scroll dan pilih "Add to Home Screen"
4. Klik "Add"
5. Icon app muncul di home screen!

**Desktop (Chrome/Edge):**
1. Buka di Chrome/Edge
2. Klik icon install (⊕) di address bar
3. Klik "Install"
4. App akan terbuka di window terpisah

### 3️⃣ Setup Awal

**Aktifkan Notifikasi:**
1. Klik icon ⚙️ Settings di kanan atas
2. Klik "Aktifkan Notifikasi"
3. Izinkan notifikasi di browser

**Setup Cycle Tracker:**
1. Di dashboard, klik "Setup Siklus" di widget Cycle Tracker
2. Masukkan tanggal hari pertama haid terakhir
3. Set panjang siklus (default 28 hari)
4. Set lama menstruasi (default 5 hari)
5. Klik "Simpan"

**Pilih Lokasi (untuk jadwal sholat):**
1. Klik ⚙️ Settings
2. Pilih kota kamu (Jakarta, Bandung, Surabaya, dll)
3. Klik "Simpan Pengaturan"

---

## 📖 Cara Menggunakan

### ➕ Tambah Task Baru

1. Di tab "Hari Ini", isi form:
   - **Task**: Nama aktivitas
   - **Waktu Mulai**: Jam berapa
   - **Durasi**: Berapa menit
   - **Kategori**: Pilih warna kategori
   - **Prioritas**: Urgent/High/Normal/Low
   - **Recurring**: Sekali aja / Setiap hari / dll
   - **Reminder**: Kapan mau diingatkan
   - **Catatan**: (Optional) tambahan info

2. Klik "Tambah Task"
3. Task muncul di list dengan urutan prioritas & waktu

### ✅ Checklist Task

- Klik checkbox di sebelah kiri task
- Task yang selesai akan coret & background hijau
- Progress bar otomatis update

### 🗑️ Hapus Task

- Klik icon 🗑️ di sebelah kanan task
- Konfirmasi hapus
- Task hilang dari list

### 📅 Lihat Calendar

1. Klik tab "Calendar"
2. Lihat semua task dalam 1 bulan
3. Klik "◀️ Bulan Lalu" atau "Bulan Depan ▶️" untuk navigasi
4. Dot berwarna = ada task di tanggal itu

### 📆 Planning Seminggu

1. Klik tab "Week Plan"
2. Lihat 7 hari sekaligus
3. Klik "◀️ Minggu Lalu" atau "Minggu Depan ▶️"
4. Checklist task langsung dari sini

### ✅ Tracking Habit

1. Klik tab "Habits"
2. Tambah habit baru (nama + target streak)
3. Klik "Tambah Habit"
4. Setiap hari, klik huruf hari (M/S/S/R/K/J/S) untuk centang
5. Lihat streak 🔥 naik!

### 📝 Gunakan Template

1. Klik tab "Templates"
2. Pilih template yang sesuai:
   - **Morning Routine**: Rutinitas pagi
   - **Work Day**: Hari kerja
   - **Period Days**: Saat haid (light activities)
   - **Weekend**: Akhir pekan
   - **Study Day**: Fokus belajar
   - **Workout Day**: Olahraga

3. Klik template
4. Konfirmasi
5. Semua task dari template langsung masuk ke hari ini!

### 📊 Lihat Analytics

1. Klik tab "Analytics"
2. Lihat statistik:
   - Tasks minggu ini
   - Produktivitas %
   - Streak hari
   - Sholat tepat waktu
3. Chart menunjukkan trend 7 hari
4. Produktivitas per kategori

### 🕌 Checklist Sholat

1. Di dashboard, lihat widget "Jadwal Sholat"
2. Setelah sholat, centang checkbox di sebelah kanan
3. Warna hijau = sudah sholat
4. Analytics akan tracking persentase sholat tepat waktu

---

## 💾 Backup & Restore

### 📥 Export Backup

1. Klik "💾 Backup" di kanan atas
2. Klik "Download Backup"
3. File JSON akan terdownload
4. **Simpan file ini dengan aman!**

### 📤 Import Backup

1. Klik "💾 Backup"
2. Klik "Choose File" dan pilih file backup
3. Klik "Import Backup"
4. Semua data akan kembali!

### 🔄 Reset Data

⚠️ **HATI-HATI**: Data akan hilang permanen!

1. Klik "💾 Backup"
2. Scroll ke bawah ke "Reset Data"
3. Klik "Reset Semua Data"
4. Konfirmasi 2x
5. Semua data terhapus

---

## 🎯 Tips & Trik

### ⚡ Produktivitas Maksimal

1. **Mulai dengan Template** - Pakai template untuk hari-hari rutin
2. **Set Prioritas** - Tandai yang urgent dengan merah
3. **Time Blocking** - Atur durasi setiap task
4. **Check Morning** - Lihat agenda pagi hari
5. **Review Malam** - Cek analytics sebelum tidur

### 🩸 Manfaatkan Cycle Tracker

- **Fase Folikuler (Hari 6-13)**: Schedule meeting penting, workout intense
- **Ovulasi (Hari 14-16)**: Social activities, presentasi
- **Luteal (Hari 17-28)**: Self-care, light activities
- **Menstruasi (Hari 1-5)**: Rest mode, pakai template "Period Days"

### 🕌 Konsisten Ibadah

- Aktifkan notifikasi adzan
- Checklist setiap sholat
- Target 100% sholat tepat waktu seminggu
- Lihat progress di Analytics

### ✅ Building Habits

- Mulai dengan 1-2 habit dulu
- Target realistis (21 hari pertama)
- Centang setiap hari konsisten
- Rayakan milestone!

### 📊 Monitor Progress

- Cek Analytics setiap minggu
- Perhatikan trend naik/turun
- Identifikasi kategori yang kurang
- Adjust planning minggu depan

---

## ❓ FAQ

**Q: Data akan hilang gak kalau tutup browser?**
A: Tidak! Data tersimpan di localStorage browser. Tapi tetap backup rutin!

**Q: Bisa diakses dari HP & laptop yang berbeda?**
A: Untuk sekarang, data tersimpan per device. Solusi: Export backup dari device 1, lalu Import di device 2.

**Q: Kenapa notifikasi gak muncul?**
A: Pastikan sudah izinkan notifikasi di Settings browser. Dan buka app-nya (biar service worker jalan).

**Q: Bisa ganti jadwal sholat?**
A: Bisa! Klik Settings → Pilih kota → Simpan.

**Q: Template bisa diedit?**
A: Untuk sekarang belum. Tapi kamu bisa apply template lalu edit manual task-nya.

**Q: Maksimal berapa task?**
A: Unlimited! Tapi recommend max 20-30 task per hari biar gak overwhelm.

**Q: Recurring task otomatis muncul setiap hari?**
A: Ya! Task recurring akan otomatis muncul sesuai pola yang dipilih.

**Q: Bisa sync ke Google Calendar?**
A: Belum untuk versi ini. Tapi fitur export/import sudah bisa backup data.

---

## 🐛 Troubleshooting

**Problem: Notifikasi tidak muncul**
- Solution: Cek Settings browser → izinkan notifikasi untuk website ini
- Pastikan app dibuka (minimal di background)

**Problem: Data hilang setelah clear browser**
- Solution: Jangan clear localStorage! Atau backup rutin.

**Problem: Task tidak tersimpan**
- Solution: Cek apakah ada error di console browser (F12)
- Refresh page lalu coba lagi

**Problem: Cycle tracker tidak akurat**
- Solution: Update data dengan tanggal yang benar
- Cycle irregular? Catat manual setiap bulan

**Problem: App lambat**
- Solution: Hapus task lama yang tidak perlu
- Export backup → Reset data → Import kembali

---

## 📞 Support

Ada masalah atau saran? 
- Cek FAQ di atas
- Backup data sebelum troubleshoot
- Report bug via thumbs down di response

---

## 🎉 Selamat Produktif!

Mulai sekarang, hidup kamu lebih terorganisir dengan:
- ✅ Task management yang powerful
- 🕌 Tracking ibadah konsisten
- 🩸 Cycle-aware planning
- 📊 Data-driven productivity
- 🔥 Habit building yang solid

**Remember**: Tools hanya alat. Yang penting adalah **konsistensi** dan **action**! 💪

Yuk mulai hari ini dengan lebih produktif dan terarah! 🚀
