// ========================
// GLOBAL STATE & VARIABLES
// ========================
let tasks = [];
let habits = [];
let prayerTimes = {};
let cycleData = null;
let currentDate = new Date();
let currentWeekStart = new Date();
let selectedCategory = 'pribadi';
let selectedPriority = 'normal';
let settings = {
    location: 'jakarta',
    notifications: false
};

// Templates
const TEMPLATES = {
    morning: [
        { title: 'Sholat Subuh', time: '04:45', category: 'ibadah', priority: 'urgent', duration: 15 },
        { title: 'Dzikir Pagi', time: '05:00', category: 'ibadah', priority: 'high', duration: 10 },
        { title: 'Olahraga/Peregangan', time: '05:30', category: 'olahraga', priority: 'normal', duration: 30 },
        { title: 'Mandi & Bersiap', time: '06:00', category: 'pribadi', priority: 'normal', duration: 30 },
        { title: 'Sarapan Bergizi', time: '07:00', category: 'pribadi', priority: 'normal', duration: 30 }
    ],
    work: [
        { title: 'Review Email & Planning', time: '08:00', category: 'kerja', priority: 'high', duration: 30 },
        { title: 'Deep Work Session 1', time: '08:30', category: 'kerja', priority: 'urgent', duration: 90 },
        { title: 'Break & Coffee', time: '10:00', category: 'pribadi', priority: 'normal', duration: 15 },
        { title: 'Meeting/Collaboration', time: '10:15', category: 'kerja', priority: 'high', duration: 60 },
        { title: 'Sholat Dzuhur', time: '12:00', category: 'ibadah', priority: 'urgent', duration: 15 },
        { title: 'Makan Siang', time: '12:30', category: 'pribadi', priority: 'normal', duration: 45 },
        { title: 'Deep Work Session 2', time: '14:00', category: 'kerja', priority: 'high', duration: 90 },
        { title: 'Sholat Ashar', time: '15:30', category: 'ibadah', priority: 'urgent', duration: 15 }
    ],
    period: [
        { title: 'Bangun & Stretching Ringan', time: '06:00', category: 'olahraga', priority: 'normal', duration: 15 },
        { title: 'Sarapan Hangat', time: '07:00', category: 'pribadi', priority: 'normal', duration: 30 },
        { title: 'Light Activities', time: '09:00', category: 'kerja', priority: 'low', duration: 120 },
        { title: 'Rest & Self-care', time: '13:00', category: 'pribadi', priority: 'high', duration: 60 },
        { title: 'Dzikir & Doa', time: '16:00', category: 'ibadah', priority: 'normal', duration: 20 },
        { title: 'Me Time', time: '19:00', category: 'pribadi', priority: 'high', duration: 90 }
    ],
    weekend: [
        { title: 'Sleep In 😴', time: '07:00', category: 'pribadi', priority: 'normal', duration: 60 },
        { title: 'Sholat Subuh (Qadha if needed)', time: '08:00', category: 'ibadah', priority: 'high', duration: 15 },
        { title: 'Sarapan Keluarga', time: '09:00', category: 'keluarga', priority: 'normal', duration: 60 },
        { title: 'Quality Time Keluarga', time: '10:00', category: 'keluarga', priority: 'high', duration: 180 },
        { title: 'Sholat Dzuhur', time: '12:00', category: 'ibadah', priority: 'urgent', duration: 15 },
        { title: 'Hobi/Me Time', time: '15:00', category: 'hobi', priority: 'normal', duration: 120 }
    ],
    study: [
        { title: 'Review Materi Kemarin', time: '08:00', category: 'belajar', priority: 'high', duration: 30 },
        { title: 'Study Session 1', time: '08:30', category: 'belajar', priority: 'urgent', duration: 90 },
        { title: 'Break', time: '10:00', category: 'pribadi', priority: 'normal', duration: 15 },
        { title: 'Study Session 2', time: '10:15', category: 'belajar', priority: 'urgent', duration: 90 },
        { title: 'Sholat Dzuhur', time: '12:00', category: 'ibadah', priority: 'urgent', duration: 15 },
        { title: 'Latihan Soal', time: '14:00', category: 'belajar', priority: 'high', duration: 90 }
    ],
    workout: [
        { title: 'Warm Up', time: '06:00', category: 'olahraga', priority: 'normal', duration: 10 },
        { title: 'Cardio Training', time: '06:10', category: 'olahraga', priority: 'high', duration: 30 },
        { title: 'Strength Training', time: '06:40', category: 'olahraga', priority: 'high', duration: 40 },
        { title: 'Cool Down & Stretching', time: '07:20', category: 'olahraga', priority: 'normal', duration: 10 },
        { title: 'Protein Shake', time: '07:30', category: 'pribadi', priority: 'normal', duration: 10 }
    ]
};

// Prayer times database (simplified - Jakarta timezone)
const PRAYER_TIMES_DB = {
    jakarta: {
        subuh: '04:45',
        dzuhur: '11:52',
        ashar: '15:10',
        maghrib: '17:58',
        isya: '19:12'
    },
    bandung: {
        subuh: '04:35',
        dzuhur: '11:47',
        ashar: '15:05',
        maghrib: '17:53',
        isya: '19:07'
    },
    surabaya: {
        subuh: '04:20',
        dzuhur: '11:35',
        ashar: '14:55',
        maghrib: '17:43',
        isya: '18:57'
    }
};

// ========================
// INITIALIZATION
// ========================
document.addEventListener('DOMContentLoaded', function() {
    loadAllData();
    initializeApp();
    setupEventListeners();
    requestNotificationPermission();
    
    // Update every minute
    setInterval(updateCurrentTime, 60000);
    setInterval(checkReminders, 60000);
    
    // Auto-save every 30 seconds
    setInterval(saveAllData, 30000);
});

function initializeApp() {
    updateCurrentDate();
    updatePrayerTimes();
    updateCycleTracker();
    updateDashboard();
    renderTodayTasks();
    renderCalendar();
    renderWeeklyView();
    renderHabits();
    renderAnalytics();
}

function setupEventListeners() {
    // Task form
    document.getElementById('taskForm').addEventListener('submit', function(e) {
        e.preventDefault();
        addTask();
    });

    // Habit form
    document.getElementById('habitForm').addEventListener('submit', function(e) {
        e.preventDefault();
        addHabit();
    });

    // Cycle form
    document.getElementById('cycleForm').addEventListener('submit', function(e) {
        e.preventDefault();
        saveCycleData();
    });

    // Category selection
    document.querySelectorAll('.category-badge').forEach(badge => {
        badge.addEventListener('click', function() {
            document.querySelectorAll('.category-badge').forEach(b => b.classList.remove('selected'));
            this.classList.add('selected');
            selectedCategory = this.dataset.cat;
        });
    });

    // Priority selection
    document.querySelectorAll('.priority-badge').forEach(badge => {
        badge.addEventListener('click', function() {
            document.querySelectorAll('.priority-badge').forEach(b => b.classList.remove('selected'));
            this.classList.add('selected');
            selectedPriority = this.dataset.pri;
        });
    });
}

// ========================
// DATE & TIME UTILITIES
// ========================
function updateCurrentDate() {
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    const now = new Date();
    const dateStr = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
    document.getElementById('currentDate').textContent = dateStr;
}

function updateCurrentTime() {
    updatePrayerTimes();
    checkReminders();
}

function getToday() {
    return new Date().toISOString().split('T')[0];
}

function formatDate(date) {
    return date.toISOString().split('T')[0];
}

// ========================
// TASK MANAGEMENT
// ========================
function addTask() {
    const title = document.getElementById('taskTitle').value;
    const time = document.getElementById('taskTime').value;
    const duration = parseInt(document.getElementById('taskDuration').value);
    const recurring = document.getElementById('taskRecurring').value;
    const reminder = document.getElementById('taskReminder').value;
    const notes = document.getElementById('taskNotes').value;

    const task = {
        id: Date.now(),
        title: title,
        time: time,
        duration: duration,
        category: selectedCategory,
        priority: selectedPriority,
        recurring: recurring,
        reminder: reminder,
        notes: notes,
        completed: false,
        createdDate: getToday(),
        date: getToday()
    };

    tasks.push(task);
    saveAllData();
    renderTodayTasks();
    renderCalendar();
    renderWeeklyView();
    updateDashboard();
    
    resetTaskForm();
    showNotification('✅ Task ditambahkan!', `${title} dijadwalkan jam ${time}`);
}

function resetTaskForm() {
    document.getElementById('taskForm').reset();
    document.getElementById('taskDuration').value = 30;
    document.querySelectorAll('.priority-badge').forEach(b => b.classList.remove('selected'));
    document.querySelector('.priority-badge[data-pri="normal"]').classList.add('selected');
    selectedPriority = 'normal';
}

function toggleTask(id) {
    const task = tasks.find(t => t.id === id);
    if (task) {
        task.completed = !task.completed;
        saveAllData();
        renderTodayTasks();
        updateDashboard();
        renderAnalytics();
    }
}

function deleteTask(id) {
    if (confirm('Yakin ingin menghapus task ini?')) {
        tasks = tasks.filter(t => t.id !== id);
        saveAllData();
        renderTodayTasks();
        renderCalendar();
        renderWeeklyView();
        updateDashboard();
    }
}

function renderTodayTasks() {
    const container = document.getElementById('todayTaskList');
    const today = getToday();
    const dayOfWeek = new Date().getDay();
    
    let todayTasks = tasks.filter(task => {
        if (task.date === today) return true;
        if (task.recurring === 'none') return false;
        if (task.recurring === 'daily') return true;
        if (task.recurring === 'weekdays' && dayOfWeek >= 1 && dayOfWeek <= 5) return true;
        if (task.recurring === 'weekends' && (dayOfWeek === 0 || dayOfWeek === 6)) return true;
        if (task.recurring === 'weekly' && new Date(task.createdDate).getDay() === dayOfWeek) return true;
        return false;
    });

    // Sort by priority then time
    todayTasks.sort((a, b) => {
        const priorityOrder = { urgent: 0, high: 1, normal: 2, low: 3 };
        if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
            return priorityOrder[a.priority] - priorityOrder[b.priority];
        }
        return a.time.localeCompare(b.time);
    });

    if (todayTasks.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">📝</div>
                <div class="empty-text">Belum ada task. Yuk mulai produktif!</div>
            </div>
        `;
        return;
    }

    container.innerHTML = todayTasks.map(task => `
        <div class="task-item ${task.completed ? 'completed' : ''}" style="border-left-color: ${getCategoryColor(task.category)}">
            <input type="checkbox" class="task-checkbox" ${task.completed ? 'checked' : ''} onchange="toggleTask(${task.id})">
            <span class="task-time">${task.time}</span>
            <span class="task-text">
                ${task.title}
                ${task.notes ? `<br><small style="color: #666;">${task.notes}</small>` : ''}
            </span>
            <span class="task-category cat-${task.category}">${getCategoryEmoji(task.category)} ${task.category}</span>
            <span class="task-category pri-${task.priority}">${task.priority}</span>
            ${task.recurring !== 'none' ? `<span style="font-size: 0.8em;">🔁</span>` : ''}
            <div class="task-actions">
                <button class="task-btn" onclick="deleteTask(${task.id})" title="Hapus">🗑️</button>
            </div>
        </div>
    `).join('');
}

function getCategoryEmoji(category) {
    const emojis = {
        kerja: '💼',
        pribadi: '🧘',
        olahraga: '💪',
        belajar: '📚',
        ibadah: '🕌',
        keluarga: '👨‍👩‍👧',
        hobi: '🎨'
    };
    return emojis[category] || '📌';
}

function getCategoryColor(category) {
    const colors = {
        kerja: '#3498db',
        pribadi: '#e74c3c',
        olahraga: '#2ecc71',
        belajar: '#f39c12',
        ibadah: '#16a085',
        keluarga: '#9b59b6',
        hobi: '#e67e22'
    };
    return colors[category] || '#667eea';
}

// ========================
// CALENDAR VIEW
// ========================
function renderCalendar() {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    document.getElementById('calendarMonth').textContent = `${months[month]} ${year}`;
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const prevLastDay = new Date(year, month, 0);
    
    const firstDayWeek = firstDay.getDay();
    const lastDate = lastDay.getDate();
    const prevLastDate = prevLastDay.getDate();
    
    const container = document.getElementById('calendarGrid');
    let html = '';
    
    // Previous month days
    for (let i = firstDayWeek - 1; i >= 0; i--) {
        const date = new Date(year, month - 1, prevLastDate - i);
        html += renderCalendarDay(date, true);
    }
    
    // Current month days
    for (let i = 1; i <= lastDate; i++) {
        const date = new Date(year, month, i);
        html += renderCalendarDay(date, false);
    }
    
    // Next month days
    const remainingDays = 42 - (firstDayWeek + lastDate);
    for (let i = 1; i <= remainingDays; i++) {
        const date = new Date(year, month + 1, i);
        html += renderCalendarDay(date, true);
    }
    
    container.innerHTML = html;
}

function renderCalendarDay(date, otherMonth) {
    const dateStr = formatDate(date);
    const today = getToday();
    const isToday = dateStr === today;
    
    const dayTasks = tasks.filter(t => t.date === dateStr);
    const taskDots = dayTasks.slice(0, 3).map(t => 
        `<span class="day-task-dot" style="background: ${getCategoryColor(t.category)}"></span>`
    ).join('');
    
    return `
        <div class="calendar-day ${otherMonth ? 'other-month' : ''} ${isToday ? 'today' : ''}" onclick="selectDate('${dateStr}')">
            <div class="day-number">${date.getDate()}</div>
            <div class="day-tasks">${taskDots}</div>
        </div>
    `;
}

function previousMonth() {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar();
}

function nextMonth() {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar();
}

function selectDate(dateStr) {
    // Future: open modal to add/view tasks for this date
    console.log('Selected date:', dateStr);
}

// ========================
// WEEKLY VIEW
// ========================
function renderWeeklyView() {
    const container = document.getElementById('weeklyGrid');
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    
    let html = '';
    
    for (let i = 0; i < 7; i++) {
        const date = new Date(currentWeekStart);
        date.setDate(date.getDate() + i);
        const dateStr = formatDate(date);
        const isToday = dateStr === getToday();
        
        const dayTasks = tasks.filter(t => t.date === dateStr);
        
        html += `
            <div class="weekly-day">
                <div class="weekly-day-header">
                    <span>${days[date.getDay()]}, ${date.getDate()}</span>
                    ${isToday ? '<span style="color: var(--primary);">● Hari Ini</span>' : ''}
                </div>
                <div class="task-list">
                    ${dayTasks.length === 0 ? '<div style="color: #999; padding: 10px;">Belum ada task</div>' : ''}
                    ${dayTasks.map(task => `
                        <div class="task-item ${task.completed ? 'completed' : ''}" style="border-left-color: ${getCategoryColor(task.category)}">
                            <input type="checkbox" class="task-checkbox" ${task.completed ? 'checked' : ''} onchange="toggleTask(${task.id})">
                            <span class="task-time">${task.time}</span>
                            <span class="task-text">${task.title}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    container.innerHTML = html;
}

function previousWeek() {
    currentWeekStart.setDate(currentWeekStart.getDate() - 7);
    renderWeeklyView();
}

function nextWeek() {
    currentWeekStart.setDate(currentWeekStart.getDate() + 7);
    renderWeeklyView();
}

// ========================
// PRAYER TIMES
// ========================
function updatePrayerTimes() {
    const location = settings.location || 'jakarta';
    prayerTimes = PRAYER_TIMES_DB[location] || PRAYER_TIMES_DB.jakarta;
    
    const now = new Date();
    const currentTime = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
    
    const prayers = [
        { name: 'Subuh', time: prayerTimes.subuh, emoji: '🌅' },
        { name: 'Dzuhur', time: prayerTimes.dzuhur, emoji: '☀️' },
        { name: 'Ashar', time: prayerTimes.ashar, emoji: '🌤️' },
        { name: 'Maghrib', time: prayerTimes.maghrib, emoji: '🌆' },
        { name: 'Isya', time: prayerTimes.isya, emoji: '🌙' }
    ];
    
    let currentPrayer = null;
    let nextPrayer = prayers[0];
    
    for (let i = 0; i < prayers.length; i++) {
        if (currentTime >= prayers[i].time) {
            currentPrayer = prayers[i];
            nextPrayer = prayers[i + 1] || prayers[0];
        }
    }
    
    const container = document.getElementById('prayerTimes');
    container.innerHTML = prayers.map(prayer => {
        const isCurrent = currentPrayer && prayer.name === currentPrayer.name;
        const prayerData = loadPrayerData(getToday(), prayer.name.toLowerCase());
        
        return `
            <div class="prayer-item ${isCurrent ? 'current' : ''} ${prayerData.completed ? 'completed' : ''}">
                <div class="prayer-name">
                    ${prayer.emoji} ${prayer.name}
                </div>
                <div class="prayer-time">${prayer.time}</div>
                <input type="checkbox" class="prayer-check" ${prayerData.completed ? 'checked' : ''} 
                       onchange="togglePrayer('${prayer.name.toLowerCase()}')">
            </div>
        `;
    }).join('');
    
    if (nextPrayer) {
        const timeUntil = calculateTimeUntil(nextPrayer.time);
        document.getElementById('nextPrayer').textContent = `${nextPrayer.emoji} ${nextPrayer.name} dalam ${timeUntil}`;
    }
}

function calculateTimeUntil(time) {
    const now = new Date();
    const [hours, minutes] = time.split(':').map(Number);
    const target = new Date();
    target.setHours(hours, minutes, 0);
    
    if (target < now) {
        target.setDate(target.getDate() + 1);
    }
    
    const diff = target - now;
    const diffHours = Math.floor(diff / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (diffHours > 0) {
        return `${diffHours} jam ${diffMinutes} menit`;
    }
    return `${diffMinutes} menit`;
}

function togglePrayer(prayerName) {
    const today = getToday();
    const key = `prayer_${today}_${prayerName}`;
    const current = localStorage.getItem(key) === 'true';
    localStorage.setItem(key, !current);
    updatePrayerTimes();
    renderAnalytics();
}

function loadPrayerData(date, prayerName) {
    const key = `prayer_${date}_${prayerName}`;
    return {
        completed: localStorage.getItem(key) === 'true'
    };
}

// ========================
// CYCLE TRACKER
// ========================
function updateCycleTracker() {
    if (!cycleData) {
        document.getElementById('cycleDay').textContent = '-';
        document.getElementById('cyclePhase').textContent = 'Klik setup untuk mulai tracking';
        return;
    }
    
    const today = new Date();
    const lastPeriod = new Date(cycleData.lastPeriodDate);
    const daysSince = Math.floor((today - lastPeriod) / (1000 * 60 * 60 * 24));
    const cycleDay = (daysSince % cycleData.cycleLength) + 1;
    
    let phase = '';
    let phaseEmoji = '';
    
    if (cycleDay <= cycleData.periodLength) {
        phase = 'Menstruasi';
        phaseEmoji = '🩸';
    } else if (cycleDay <= 13) {
        phase = 'Fase Folikuler (Energi Tinggi!)';
        phaseEmoji = '⚡';
    } else if (cycleDay <= 16) {
        phase = 'Ovulasi (Peak Energy!)';
        phaseEmoji = '✨';
    } else {
        phase = 'Fase Luteal (Self-care Time)';
        phaseEmoji = '🌙';
    }
    
    document.getElementById('cycleDay').textContent = `Hari ${cycleDay}`;
    document.getElementById('cyclePhase').textContent = `${phaseEmoji} ${phase}`;
}

function showCycleSetup() {
    document.getElementById('cycleModal').classList.add('active');
    if (cycleData) {
        document.getElementById('lastPeriodDate').value = cycleData.lastPeriodDate;
        document.getElementById('cycleLength').value = cycleData.cycleLength;
        document.getElementById('periodLength').value = cycleData.periodLength;
    }
}

function closeCycleModal() {
    document.getElementById('cycleModal').classList.remove('active');
}

function saveCycleData() {
    cycleData = {
        lastPeriodDate: document.getElementById('lastPeriodDate').value,
        cycleLength: parseInt(document.getElementById('cycleLength').value),
        periodLength: parseInt(document.getElementById('periodLength').value)
    };
    saveAllData();
    updateCycleTracker();
    closeCycleModal();
    showNotification('✅ Cycle data tersimpan!');
}

// ========================
// HABITS
// ========================
function addHabit() {
    const title = document.getElementById('habitTitle').value;
    const target = parseInt(document.getElementById('habitTarget').value);
    
    const habit = {
        id: Date.now(),
        title: title,
        target: target,
        streak: 0,
        completions: {}
    };
    
    habits.push(habit);
    saveAllData();
    renderHabits();
    document.getElementById('habitForm').reset();
    showNotification('✅ Habit ditambahkan!');
}

function renderHabits() {
    const container = document.getElementById('habitList');
    
    if (habits.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">✨</div>
                <div class="empty-text">Mulai tracking kebiasaan baikmu!</div>
            </div>
        `;
        return;
    }
    
    container.innerHTML = habits.map(habit => {
        const last7Days = getLast7Days();
        const streak = calculateStreak(habit);
        
        return `
            <div class="habit-card">
                <div class="habit-header">
                    <div class="habit-name">${habit.title}</div>
                    <div class="habit-streak">${streak} 🔥</div>
                </div>
                <div class="habit-days">
                    ${last7Days.map((date, index) => {
                        const dayNames = ['M', 'S', 'S', 'R', 'K', 'J', 'S'];
                        const dayOfWeek = new Date(date).getDay();
                        const completed = habit.completions[date] || false;
                        
                        return `
                            <div class="habit-day ${completed ? 'completed' : ''}" 
                                 onclick="toggleHabit(${habit.id}, '${date}')"
                                 title="${date}">
                                ${dayNames[dayOfWeek]}
                            </div>
                        `;
                    }).join('')}
                </div>
                <div style="margin-top: 15px; text-align: right;">
                    <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 0.85em;" 
                            onclick="deleteHabit(${habit.id})">🗑️</button>
                </div>
            </div>
        `;
    }).join('');
}

function toggleHabit(habitId, date) {
    const habit = habits.find(h => h.id === habitId);
    if (habit) {
        habit.completions[date] = !habit.completions[date];
        saveAllData();
        renderHabits();
    }
}

function deleteHabit(id) {
    if (confirm('Yakin ingin menghapus habit ini?')) {
        habits = habits.filter(h => h.id !== id);
        saveAllData();
        renderHabits();
    }
}

function calculateStreak(habit) {
    let streak = 0;
    const today = new Date();
    
    for (let i = 0; i < 365; i++) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        const dateStr = formatDate(date);
        
        if (habit.completions[dateStr]) {
            streak++;
        } else {
            break;
        }
    }
    
    return streak;
}

// ========================
// TEMPLATES
// ========================
function applyTemplate(templateName) {
    const template = TEMPLATES[templateName];
    if (!template) return;
    
    if (!confirm(`Tambahkan ${template.length} tasks dari template ${templateName}?`)) {
        return;
    }
    
    const today = getToday();
    template.forEach(taskData => {
        const task = {
            id: Date.now() + Math.random(),
            title: taskData.title,
            time: taskData.time,
            duration: taskData.duration,
            category: taskData.category,
            priority: taskData.priority,
            recurring: 'none',
            reminder: 'ontime',
            notes: '',
            completed: false,
            createdDate: today,
            date: today
        };
        tasks.push(task);
    });
    
    saveAllData();
    renderTodayTasks();
    renderCalendar();
    updateDashboard();
    switchTab('today');
    showNotification(`✅ Template ${templateName} diterapkan!`, `${template.length} tasks ditambahkan`);
}

function createCustomTemplate() {
    alert('Fitur custom template akan segera hadir! 🚀');
}

// ========================
// ANALYTICS
// ========================
function renderAnalytics() {
    const last7Days = getLast7Days();
    
    // Calculate stats
    let weeklyCompleted = 0;
    let weeklyTotal = 0;
    
    last7Days.forEach(date => {
        const dayTasks = tasks.filter(t => t.date === date);
        weeklyTotal += dayTasks.length;
        weeklyCompleted += dayTasks.filter(t => t.completed).length;
    });
    
    const productivity = weeklyTotal > 0 ? Math.round((weeklyCompleted / weeklyTotal) * 100) : 0;
    
    // Calculate streak
    let streak = 0;
    for (let i = last7Days.length - 1; i >= 0; i--) {
        const date = last7Days[i];
        const dayTasks = tasks.filter(t => t.date === date);
        const completed = dayTasks.filter(t => t.completed).length;
        
        if (completed > 0) {
            streak++;
        } else {
            break;
        }
    }
    
    // Prayer completion
    let prayerCompleted = 0;
    let prayerTotal = 0;
    last7Days.forEach(date => {
        ['subuh', 'dzuhur', 'ashar', 'maghrib', 'isya'].forEach(prayer => {
            prayerTotal++;
            if (loadPrayerData(date, prayer).completed) {
                prayerCompleted++;
            }
        });
    });
    const prayerCompletion = prayerTotal > 0 ? Math.round((prayerCompleted / prayerTotal) * 100) : 0;
    
    document.getElementById('weeklyCompleted').textContent = weeklyCompleted;
    document.getElementById('weeklyProductivity').textContent = productivity + '%';
    document.getElementById('currentStreak').textContent = streak;
    document.getElementById('prayerCompletion').textContent = prayerCompletion + '%';
    
    // Render charts
    renderWeeklyChart(last7Days);
    renderCategoryChart();
}

function renderWeeklyChart(days) {
    const container = document.getElementById('weeklyChart');
    const dayNames = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
    
    const maxCompleted = Math.max(...days.map(date => {
        const dayTasks = tasks.filter(t => t.date === date);
        return dayTasks.filter(t => t.completed).length;
    }), 1);
    
    container.innerHTML = days.map(date => {
        const dayTasks = tasks.filter(t => t.date === date);
        const completed = dayTasks.filter(t => t.completed).length;
        const total = dayTasks.length;
        const dayOfWeek = new Date(date).getDay();
        const width = (completed / maxCompleted) * 100;
        
        return `
            <div class="chart-bar">
                <div class="chart-label">${dayNames[dayOfWeek]}</div>
                <div class="chart-bar-bg">
                    <div class="chart-bar-fill" style="width: ${width}%">
                        ${completed}/${total}
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

function renderCategoryChart() {
    const container = document.getElementById('categoryChart');
    const categories = ['kerja', 'pribadi', 'olahraga', 'belajar', 'ibadah', 'keluarga', 'hobi'];
    
    const categoryCounts = {};
    categories.forEach(cat => {
        const catTasks = tasks.filter(t => t.category === cat && t.completed);
        categoryCounts[cat] = catTasks.length;
    });
    
    const maxCount = Math.max(...Object.values(categoryCounts), 1);
    
    container.innerHTML = categories.map(cat => {
        const count = categoryCounts[cat];
        const width = (count / maxCount) * 100;
        
        return `
            <div class="chart-bar">
                <div class="chart-label">${getCategoryEmoji(cat)} ${cat}</div>
                <div class="chart-bar-bg">
                    <div class="chart-bar-fill" style="width: ${width}%; background: ${getCategoryColor(cat)}">
                        ${count}
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// ========================
// DASHBOARD
// ========================
function updateDashboard() {
    const today = getToday();
    const todayTasks = tasks.filter(t => t.date === today);
    const completed = todayTasks.filter(t => t.completed).length;
    const total = todayTasks.length;
    const urgent = todayTasks.filter(t => t.priority === 'urgent' && !t.completed).length;
    
    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
    
    document.getElementById('todayProgress').style.width = percentage + '%';
    document.getElementById('todayProgress').textContent = percentage + '%';
    document.getElementById('todayCompleted').textContent = completed + '/' + total;
    document.getElementById('todayUrgent').textContent = urgent;
}

// ========================
// NOTIFICATIONS
// ========================
function requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
                showNotification('🔔 Notifikasi Aktif!', 'Kamu akan dapat reminder untuk semua task & sholat!');
                settings.notifications = true;
                saveAllData();
            }
        });
    }
}

function showNotification(title, body = '') {
    // Show in-app notification
    const notif = document.getElementById('notification');
    document.getElementById('notificationText').innerHTML = `<strong>${title}</strong>${body ? '<br>' + body : ''}`;
    notif.classList.add('show');
    
    setTimeout(() => {
        notif.classList.remove('show');
    }, 4000);
    
    // Show browser notification
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(title, {
            body: body,
            icon: '📅',
            badge: '📅'
        });
    }
}

function checkReminders() {
    const now = new Date();
    const currentTime = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
    const today = getToday();
    
    // Check task reminders
    tasks.forEach(task => {
        if (task.completed || task.date !== today) return;
        
        let reminderTime = task.time;
        if (task.reminder !== 'ontime') {
            const [hours, minutes] = task.time.split(':').map(Number);
            const taskDate = new Date();
            taskDate.setHours(hours, minutes, 0);
            taskDate.setMinutes(taskDate.getMinutes() - parseInt(task.reminder));
            reminderTime = taskDate.getHours().toString().padStart(2, '0') + ':' + 
                         taskDate.getMinutes().toString().padStart(2, '0');
        }
        
        if (reminderTime === currentTime) {
            const msg = task.reminder === 'ontime' 
                ? `Waktunya: ${task.title}` 
                : `${task.reminder} menit lagi: ${task.title}`;
            showNotification('⏰ Reminder Task!', msg);
        }
    });
    
    // Check prayer reminders
    Object.keys(prayerTimes).forEach(prayer => {
        if (prayerTimes[prayer] === currentTime) {
            showNotification('🕌 Adzan ' + prayer.charAt(0).toUpperCase() + prayer.slice(1), 'Waktunya sholat!');
        }
    });
}

// ========================
// DATA PERSISTENCE
// ========================
function saveAllData() {
    localStorage.setItem('dailyplanner_tasks', JSON.stringify(tasks));
    localStorage.setItem('dailyplanner_habits', JSON.stringify(habits));
    localStorage.setItem('dailyplanner_cycle', JSON.stringify(cycleData));
    localStorage.setItem('dailyplanner_settings', JSON.stringify(settings));
    
    document.getElementById('syncStatus').textContent = '☁️ Tersimpan';
    setTimeout(() => {
        document.getElementById('syncStatus').textContent = '☁️ Tersimpan';
    }, 2000);
}

function loadAllData() {
    tasks = JSON.parse(localStorage.getItem('dailyplanner_tasks') || '[]');
    habits = JSON.parse(localStorage.getItem('dailyplanner_habits') || '[]');
    cycleData = JSON.parse(localStorage.getItem('dailyplanner_cycle') || 'null');
    settings = JSON.parse(localStorage.getItem('dailyplanner_settings') || '{"location":"jakarta","notifications":false}');
}

function exportData() {
    const data = {
        tasks: tasks,
        habits: habits,
        cycleData: cycleData,
        settings: settings,
        exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `daily-planner-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    
    showNotification('✅ Backup berhasil didownload!');
}

function importData() {
    const file = document.getElementById('importFile').files[0];
    if (!file) {
        alert('Pilih file backup dulu!');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            
            tasks = data.tasks || [];
            habits = data.habits || [];
            cycleData = data.cycleData || null;
            settings = data.settings || settings;
            
            saveAllData();
            initializeApp();
            
            showNotification('✅ Data berhasil di-import!');
            closeBackupModal();
        } catch (err) {
            alert('File backup tidak valid!');
        }
    };
    reader.readAsText(file);
}

function resetAllData() {
    if (!confirm('PERHATIAN: Semua data akan dihapus permanen. Yakin ingin reset?')) {
        return;
    }
    
    if (!confirm('Yakin 100%? Data tidak bisa dikembalikan!')) {
        return;
    }
    
    localStorage.clear();
    tasks = [];
    habits = [];
    cycleData = null;
    settings = { location: 'jakarta', notifications: false };
    
    initializeApp();
    closeBackupModal();
    showNotification('🔄 Semua data telah direset');
}

// ========================
// MODAL FUNCTIONS
// ========================
function showBackupModal() {
    document.getElementById('backupModal').classList.add('active');
}

function closeBackupModal() {
    document.getElementById('backupModal').classList.remove('active');
}

function showSettingsModal() {
    document.getElementById('settingsModal').classList.add('active');
    document.getElementById('locationSelect').value = settings.location;
}

function closeSettingsModal() {
    document.getElementById('settingsModal').classList.remove('active');
}

function saveSettings() {
    settings.location = document.getElementById('locationSelect').value;
    saveAllData();
    updatePrayerTimes();
    closeSettingsModal();
    showNotification('✅ Pengaturan tersimpan!');
}

// ========================
// TAB SWITCHING
// ========================
function switchTab(tabName) {
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    event.target.classList.add('active');
    document.getElementById(tabName).classList.add('active');
    
    if (tabName === 'analytics') {
        renderAnalytics();
    }
}

// ========================
// UTILITY FUNCTIONS
// ========================
function getLast7Days() {
    const days = [];
    for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        days.push(formatDate(date));
    }
    return days;
}

// Initialize week start to this week's Sunday
currentWeekStart = new Date();
currentWeekStart.setDate(currentWeekStart.getDate() - currentWeekStart.getDay());
